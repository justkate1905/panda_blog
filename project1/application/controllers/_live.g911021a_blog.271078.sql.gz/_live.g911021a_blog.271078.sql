-- MySQL dump 10.13  Distrib 5.6.21-70.0, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: g911021a_blog
-- ------------------------------------------------------
-- Server version	5.6.26-74.0-beget-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `country` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
INSERT INTO `cities` VALUES (1,'Санкт-Петербург',3),(2,'Москва',3),(3,'Нью-Йорк',4),(4,'Лос-Анджелес',4),(5,'Париж',5),(6,'Марсель',5),(7,'Рим',6),(8,'Мадрид',7),(9,'Пекин',8);
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `id_post` int(16) NOT NULL,
  `id_user` int(16) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `public_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,12,25,'комментарий','2015-11-16 19:04:23'),(2,14,29,'Не это ли прекрасно!','2015-11-18 21:46:38');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (3,'Россия'),(4,'США'),(5,'Франция'),(6,'Италия'),(7,'Испания'),(8,'Китай');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `id_post` int(16) NOT NULL,
  `tag` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `login` varchar(255) NOT NULL,
  `activity_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` enum('Женский','Мужской','','') DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `hobby` text,
  `education` varchar(255) DEFAULT NULL,
  `about_user` text,
  `country` int(11) DEFAULT NULL,
  `city` int(11) DEFAULT NULL,
  `privileges` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,NULL,NULL,NULL,'truetnoth','2015-11-03 11:04:50','c736bd97ee5101de34c01fb475d7d2d85bbbe496','truetnoth@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(6,NULL,NULL,NULL,'123456789','2015-11-08 19:13:14','724e315454af7df143b79d631c15446cf6097c18','nastiap3@mail.ru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(25,'Екатерина','Сон','Валентиновна','root','2015-11-20 08:46:25','30d8bf9904a35efc8036c05b558a6b948d196a46','r@r.ru','Женский','1997-05-19',' ','',' ',3,1,1),(28,NULL,NULL,NULL,'w','2015-11-19 21:32:24','a9fbec103a511bcb8194335ac30b24a8fe18300b','w@w.ru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(29,'123','Нос','','123','2015-11-18 18:45:23','0e16a172c86d70cf0910bd36d13f8c28c39ec309','nastiap3@mail.ru',NULL,'0000-00-00',' ','',' ',3,NULL,0),(30,'','','','125','2015-11-19 19:39:35','0e16a172c86d70cf0910bd36d13f8c28c39ec309','eidhe',NULL,'0000-00-00',' ','',' ',3,2,0),(31,NULL,NULL,NULL,'sunny','2015-11-19 20:46:39','60b2ccbb1627a1b68740e43264b2699d1e91f410','1@r.ru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(32,NULL,NULL,NULL,'126','2015-11-19 20:50:37','3bce3a07be1e26f602a9516dd9a36b2e24cc24a4','ВЛАДАЛ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(33,NULL,NULL,NULL,'127','2015-11-20 07:22:57','cae95a78f6dd9b08d8d082231502eee151280892','ОООО',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0),(34,NULL,NULL,NULL,'shuttov','2015-11-20 08:39:45','bced5eaf279e93692ad75989994496b46d442b9a','truetnoth@gmail.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_blog`
--

DROP TABLE IF EXISTS `users_blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_blog` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `post` varchar(5000) NOT NULL,
  `id_author` int(16) NOT NULL,
  `public_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_post` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_blog`
--

LOCK TABLES `users_blog` WRITE;
/*!40000 ALTER TABLE `users_blog` DISABLE KEYS */;
INSERT INTO `users_blog` VALUES (10,'Hello world!',3,'2015-11-06 16:26:54'),(12,'Запись администратора',25,'2015-11-16 19:02:11'),(13,'еще одна запись',25,'2015-11-18 18:29:51'),(14,'Прекрасное утро',28,'2015-11-18 21:16:17'),(15,'Доброго вечера',29,'2015-11-18 21:45:51'),(18,'Это я! ',30,'2015-11-19 23:44:29'),(19,'Без 10-ти полночь, происходит какая-то вакханалия...',25,'2015-11-19 23:51:07'),(20,'Я 126!',32,'2015-11-19 23:57:54'),(21,'00:46 - все очень плохо',25,'2015-11-20 00:47:24'),(22,'10 утра ',33,'2015-11-20 10:23:21'),(23,'Сегодня я пишу первый пост в свой панда блог. Я чувствую себя очень напряжённо. Моя первая заметка... Я так счастлив... Хочу целовать всех на свете и любить... Лепестки сакуры падают со скоростью 5 сантиметров в секунду... Я люблю мир... \r\nСкоро будут новые записи в моём блоге, подписывайтесь! Я вас всех люблю, мои подписчики!',34,'2015-11-20 11:45:05'),(24,'Мой второй пост в панда блоге. Солнышко светит за окном и я сижу пишу свой блог. Я так счастлив, птички поют за окном, счастье, вот оно какое... Мой папочка выпивает утреннее сакэ и идёт на работу, насвистывая японскую народную песенку про счастливую семью... Это так мило! Я в восторге! Жизнь прекрасна, любовь царит в нашем доме! Слава Аллаху!  ᕕ( ՞ ᗜ ՞ )ᕗ',34,'2015-11-20 12:06:30');
/*!40000 ALTER TABLE `users_blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_fav`
--

DROP TABLE IF EXISTS `users_fav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_fav` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `id_post` int(16) NOT NULL,
  `id_user` int(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_fav`
--

LOCK TABLES `users_fav` WRITE;
/*!40000 ALTER TABLE `users_fav` DISABLE KEYS */;
INSERT INTO `users_fav` VALUES (38,12,28),(39,12,28),(40,15,29),(41,10,29),(44,13,30),(45,13,30),(46,15,30),(62,12,25),(63,10,25),(64,15,25),(66,14,32),(67,14,32),(70,21,25),(71,19,25),(72,23,25);
/*!40000 ALTER TABLE `users_fav` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_follow`
--

DROP TABLE IF EXISTS `users_follow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_follow` (
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `id_follower` int(16) NOT NULL,
  `id_user` int(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_follow`
--

LOCK TABLES `users_follow` WRITE;
/*!40000 ALTER TABLE `users_follow` DISABLE KEYS */;
INSERT INTO `users_follow` VALUES (2,25,3),(3,28,25),(4,29,28),(5,29,25),(6,29,3),(7,30,29),(8,25,29),(9,25,28),(10,30,25),(11,32,30),(12,32,25),(14,32,3),(15,32,28),(16,33,25),(17,25,34);
/*!40000 ALTER TABLE `users_follow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'g911021a_blog'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-20 13:02:55
