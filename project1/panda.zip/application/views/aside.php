<body class = "white-back">
    <p style = "margin-top: 20px">
      <div class="heading"></div>
      <div class="row">
        <div class="col-xs-2">
          <aside class="left_side">
            <p style=" text-align: center">
              <?php 
              echo '<img src="'.$prof_photo.'" alt="hello" class="img-circle" width="140" height="140" style = "margin-top: 0px;">' 
              ?>
            </p>
            <p style = "margin-top: 15px">
              <?php 
                echo "<h3 class = 'text-center'>".$login."</h3>";
              ?>
            </p>
          </aside>