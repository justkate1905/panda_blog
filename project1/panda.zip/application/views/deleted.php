<body class = "begin">
<div class="container ">
	<div class="row">
		<div class="col-xs-12">
			<a href="/"><img src="/img/panda-blog1.png" alt="Whitesquare logo" style = "margin-top: 10px;"></a>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-10 col-xs-offset-1">
			<h3 class = "page-header contr text-center">Извините, данный профиль был удален в связи с долгой неактивностью</h3>
		</div>
	</div>
	<div class="row">
		<div class="col-xs-6 col-xs-offset-3 text-center">
				<a href = "/auth" class = 'btn btn-lg btn-default' style="margin-bottom: 35px;">Вернуться назад</a>
		</div>
	</div>
</div>