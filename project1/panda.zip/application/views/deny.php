<?php
show_404('page');
?>