<head>
	<link href="/css/bootstrap.min.css" rel="stylesheet">

    <link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css" rel="stylesheet">
    <link href="/css/style.css" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css"> -->
    <script src="/js/jquery-1.11.3.min.js"></script>

    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/select.js"></script>
    <script>
	$(function () {
	  $('[data-toggle="tooltip"]').tooltip()
	})
    </script>
    <title>Блог</title>
	</head>

    
