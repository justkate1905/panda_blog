<body class = "white-back">
<div class="wrapper container" style = "width:100%">
<div class="row">
	<nav class="navbar navbar-default navbar-inverse">
		<ul class="nav navbar-nav">
		<li><a href="/main"><img src="/img/panda-blog1.png" alt="Whitesquare logo" style="padding: 0 0 0 0; height: 21px;"></a></li> 
  <li><a href="/main">Главная</a></li>
		
			<li><a href="/profile">Профиль</a></li>
			<li><a href="/profile/favourites">Избранное</a></li>
			<li><a href="/profile/follows">Подписки</a></li>
			            <li><a href="/profile/news">Лента</a></li>
            <li><a href="/photos">Фото</a></li>
			<li><a href="/settings">Настройки</a></li>
		</ul>
			<ul class="nav navbar-nav navbar-right">
			<li><a href="/profile/logout" style = "margin-right:15px">Выход</a></li>
          </ul>
	</nav>