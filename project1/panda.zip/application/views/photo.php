
      </div>
      <section class="col-xs-10">
        <div class="row">
        </br>
        <p><h4>Личная фотография</h4>
          <form action = "/photos/setphoto" method = "POST" enctype = "multipart/form-data">
            <div class="form-group">
              <input type="file" name = "userfile" style="width:33%" accept = "image/x-png, image/jpeg">
            </div>
            <button type="submit" class="btn btn-success">Загрузить</button>
          </form>
        </p>
      </div>
    </section>
  </div>
 </div>